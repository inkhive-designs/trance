Thanks for using Trance WordPress theme. Read the following instructions to use some of the features in the theme.

1. Social Icons - To enable the Social icons, you first need to enable them in the Customizer and then add required URL (including http:// or https://) in the icon field whose icon you wish to show on your site.

2. Most Popular Section - This one is rather simple. You just need to enable it from the Customizer. You can also change the background if you want. The desired background dimensions are 1440*500. Most Popular Posts, as the name suggests, shows the most popular posts on your site with the left most thumbnail the most popular one. There is a limit of 6 posts in this section.

3. Slider - You first need to enable it from the Customizer, then add the Image, Description and URL link for every slide. There are currently 3 slides available.